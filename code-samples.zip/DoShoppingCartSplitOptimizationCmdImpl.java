import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.order.objects.OrderItemAccessBean;

public class DoShoppingCartSplitOptimizationCmdImpl extends TaskCommandImpl
		implements DoShoppingCartSplitOptimizationCmd {

	private static final String CLASS_NAME = DoShoppingCartSplitOptimizationCmdImpl.class.getName();
	private static final Logger LOGGER = Logger.getLogger(CLASS_NAME);
	
	private static final Long MAX_COMBINATION_LIMIT = 2000L;
	
	private ArrayList<OptimizationHelperBean> orderItems;
	private Map<Integer, ArrayList<OrderItemAccessBean>> mostOptimalCombinationMap = new HashMap();
	
	private Integer storeId;
	private FulfillmentCenterInformation geoLocationFfmCenter;
	
	public void validateParameters() {
		final String METHOD_NAME = "validateParameters()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		storeId = getCommandContext().getStoreId();
		geoLocationFfmCenter = FulfillmentUtils.getGeolocationFfmCenter(getCommandContext());
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
	}
	
	public void performExecute() {
		final String METHOD_NAME = "performExecute()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		// get total combination amount
		Long totalCombinationAmount = calculateTotalCombinationAmount(orderItems);
		
		try {
			
			Integer i = 0;
			
			Long startTime = System.currentTimeMillis();
			// filter combinations if total combination amount is beyond the maximum combination limit
			// we want to be super fast!
			while(calculateTotalCombinationAmount(orderItems).compareTo(MAX_COMBINATION_LIMIT) == 1) {
				// filter the order items
				orderItems = filterCombinations(orderItems);
				
				if(++i >= 4) {
					LOGGER.info(orderItems.get(0).getOrderItem().getOrderId() + " is in infinite loop, stopping the resolving and forcing fulfillmentCenters");
					orderItems = doForcedCombinationFiltering(orderItems);

					break;
				}
			}
			
			// and then get the most optimal combination by order items
			OptimizationCombinationEntry optimizationCombination = getMostOptimalCombination(orderItems);
			
			mostOptimalCombinationMap = optimizationCombination.getResolvedCombinationMap();

			// get the optimization endtime
			Long endTime = System.currentTimeMillis();

			// and calculate the execution time
			Long executionTime = endTime - startTime;
			
			// log the optimization time
			LOGGER.info("Optimization execution time for total " + totalCombinationAmount + " combinations was " + executionTime + " ms ");
		} catch(Exception e) {
			LOGGER.log(Level.WARNING, "Unable to optimize the order items", e);
		}
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
	}
	
	/**
	 * Does the forced combination filtering for the order items if the combinations are somehow in infinite loop
	 *
	 * Could not reproduce the situation
	 * 
	 * @param orderItems
	 * @return list of orderItems
	 */
	private ArrayList<OptimizationHelperBean> doForcedCombinationFiltering(
			ArrayList<OptimizationHelperBean> orderItems) {
		final String METHOD_NAME = "doForcedCombinationFiltering()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, orderItems);
		
		ArrayList<OptimizationHelperBean> orderItemsToReturn = new ArrayList();
		
		for(OptimizationHelperBean helperBean : orderItems) {
			ArrayList<FulfillmentCenterInformation> fulfillmentCenters = helperBean.getFulfillmentCenters();
			
			ArrayList<FulfillmentCenterInformation> filteredFulfillmentCenters = new ArrayList();
			
			if(fulfillmentCenters != null && !fulfillmentCenters.isEmpty()) {
				filteredFulfillmentCenters.add(fulfillmentCenters.get(0));
			}
			
			helperBean.setFulfillmentCenters(filteredFulfillmentCenters);		
			orderItemsToReturn.add(helperBean);
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, orderItemsToReturn);
		return orderItemsToReturn;
	}

	/**
	 * Calculates total combination amount for order items
	 * @param orderItems order items
	 * @return amount of combinations
	 */
	protected Long calculateTotalCombinationAmount(ArrayList<OptimizationHelperBean> orderItems) {
		final String METHOD_NAME = "calculateTotalCombinationAmount()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, orderItems);
		
		Long totalCombinations = 1L;
		
		// loop through the order items and then multiply by the size
		for(OptimizationHelperBean orderItem : orderItems) {
			totalCombinations *= orderItem.getFulfillmentCenters().size();
		}
		
		// return the amount of combination
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, totalCombinations);
		return totalCombinations;
	}
	
	/**
	 * Filters combinations for order items
	 * @param orderItems list of optimization helper beans
	 * @return list of new optimization helper beans
	 * @throws Exception
	 */
	protected ArrayList<OptimizationHelperBean> filterCombinations(ArrayList<OptimizationHelperBean> orderItems) throws Exception {
		final String METHOD_NAME = "filterCombinations()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		// calculate total combination amount
		Long totalCombinationAmount = calculateTotalCombinationAmount(orderItems);
		
		// log the information that we are having too complex order for optimization
		LOGGER.warning("Shopping cart has " + totalCombinationAmount + " different combinations. It's over the predefined limit " + MAX_COMBINATION_LIMIT);
		LOGGER.warning("Trying to filter out by setting one common fulfillment center");
			
		// get fulfillmentCenters ids
		Set<Integer> ffmCenterIds = getAllFulfillmentCenters(orderItems);
		Set<FulfillmentCenterInformation> acceptedFfmCenters = new HashSet();
		ArrayList<FulfillmentCenterInformation> finallyAcceptedFfmCenters = new ArrayList();
			
		// filter all the fulfillment centers by prechosen fulfillment center
		for(Integer ffmCenterId : ffmCenterIds) {
			// calculate combinations by predefined fulfillment centers
			Long totalCombinations = calculateTotalCombinationsByPredefinedFulfillmentCenter(orderItems, ffmCenterId);
			
			// and if the combination amount is now lower than the limit, let's get this information
			if(totalCombinations.compareTo(MAX_COMBINATION_LIMIT) == -1) {
				acceptedFfmCenters.add(FulfillmentUtils.getFulfillmentCenter(ffmCenterId));
			}
		}		
		// and get the combination entry -map for order items
		Map<Integer, ArrayList<OptimizationCombinationEntry>> combinationEntries = new HashMap();
		
		// set the impossible init value and avoid nullchecks
		Integer minimumAmountOfFfmCenters = 10000;
		// round robin for ffm centers
		for(FulfillmentCenterInformation ffmCenter : acceptedFfmCenters) {
			Integer ffmCenterId = ffmCenter.getId();
			
			// calculate combination amount for predefined fulfillment center id, again
			Long totalCombinations = calculateTotalCombinationsByPredefinedFulfillmentCenter(orderItems, ffmCenterId);
				
			// generate the combination matrix for predefined fulfillment center id
			ArrayList<ArrayList<FulfillmentCenterInformation>> combinationMatrix = 
					generateCombinationMatrix(orderItems, totalCombinations, ffmCenterId);
				
			// and get combination entries
			ArrayList<OptimizationCombinationEntry> entries = getCombinationEntries(orderItems, combinationMatrix, totalCombinations);
			
			// if first entry has minimum amount of ffm centers, set the info
			if(entries.get(0).getNumberOfDifferentFulfillmentCenters().compareTo(minimumAmountOfFfmCenters) == -1) {
				minimumAmountOfFfmCenters = entries.get(0).getNumberOfDifferentFulfillmentCenters();
			}
			
			// put the entries to the map
			combinationEntries.put(ffmCenterId, entries);
		}
			
		// loop through the accepted ffm centers
		for(FulfillmentCenterInformation ffmCenter : acceptedFfmCenters) {
			OptimizationCombinationEntry entry = combinationEntries.get(ffmCenter.getId()).get(0);
			
			// and filter the ffm center list by minimum amount
			if(minimumAmountOfFfmCenters.compareTo(entry.getNumberOfDifferentFulfillmentCenters()) >= 0) {
				finallyAcceptedFfmCenters.add(ffmCenter);
			}
		}

		// and get he optimization helper list
		ArrayList<FulfillmentCenterOptimizationBean> ffmCenterList = new ArrayList();
			
		// loop through the accepted fulfillment centers
		for(FulfillmentCenterInformation ffmCenter : acceptedFfmCenters) {
			// get all the entries
			ArrayList<OptimizationCombinationEntry> entries = combinationEntries.get(ffmCenter.getId());
			// optimize by ffm center object and combination amount
			FulfillmentCenterOptimizationBean fulfillmentCenterOptimizationBean = new FulfillmentCenterOptimizationBean(ffmCenter, new Long(entries.size()));
			
			// and if the ffmcenter is geolocation ffmcenter, set the flag
			if(isGeoLocationFulfillmentCenter(ffmCenter)) {
				fulfillmentCenterOptimizationBean.setGeoLocationFfmCenter(true);
			}
			
			ffmCenterList.add(fulfillmentCenterOptimizationBean);
		}			
			
		// sort by custom comparator
		Collections.sort(ffmCenterList, new FulfillmentCenterOptimizationBean.FulfillmentCenterOptimizationComparator());
			
		// and init new fulfillment centers list
		ArrayList<FulfillmentCenterInformation> fulfillmentCenters = new ArrayList();
			
		// splice the most common plox
		for(int i = 0; i < (ffmCenterList.size() - 1); i++) {
			fulfillmentCenters.add(ffmCenterList.get(i).getFfmCenter());
		}
		
		// and set the order item fulfillment centers
		for(OptimizationHelperBean orderItem : orderItems) {
			orderItem.setFulfillmentCenters(filterFulfillmentCenters(orderItem.getFulfillmentCenters(), fulfillmentCenters));
		}
		
		// and then calculate the total combination after the filtering
		totalCombinationAmount = calculateTotalCombinationAmount(orderItems);
			
		// and log the info
		LOGGER.warning("Shopping cart has " + totalCombinationAmount + " different combinations after filtering.");
		
		// and return the order items
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, METHOD_NAME);
		return orderItems;
	}
	
	/**
	 * Gets all the unique fulfillment center ids from the order item helper -objects
	 * @param orderItems list of order item helper objects
	 * @return set of fulfillment center ids
	 */
	protected Set<Integer> getAllFulfillmentCenters(ArrayList<OptimizationHelperBean> orderItems) {
		final String METHOD_NAME = "getAllFulfillmentCenters()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		Set<Integer> ffmCenterIds = new HashSet();
		
		for(OptimizationHelperBean orderItem : orderItems) {
			for(FulfillmentCenterInformation fulfillmentCenter : orderItem.getFulfillmentCenters()) {
				if(!ffmCenterIds.contains(fulfillmentCenter.getId())) {
					ffmCenterIds.add(fulfillmentCenter.getId());
				}
			}
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, ffmCenterIds);
		return ffmCenterIds;
	}
	
	/**
	 * Calculates combination amount by predefined fulfillment centers
	 * @param orderItems list of fulfillment centers
	 * @param ffmCenterId fulfillment center id
	 * @return amount of total combinations
	 */
	protected Long calculateTotalCombinationsByPredefinedFulfillmentCenter(ArrayList<OptimizationHelperBean> orderItems, Integer ffmCenterId) {
		final String METHOD_NAME = "calculateTotalCombinationsByPredefinedFulfillmentCenters()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { orderItems, ffmCenterId });
		
		Long totalCombinations = 1L;
		
		// loop through the orderitems
		for(OptimizationHelperBean orderItem : orderItems) {
			Boolean ffmCenterFound = false;
			// get the size of the ffm center list
			int amountOfFfmCenters = orderItem.getFulfillmentCenters().size();
			
			// loop through the list
			for(FulfillmentCenterInformation ffmCenter : orderItem.getFulfillmentCenters()) {
				if(ffmCenter.getId().equals(ffmCenterId)) {
					ffmCenterFound = true;
					break;
				}
			}
			
			// mmkay, ffm center was found, amount is one then
			if(ffmCenterFound) {
				amountOfFfmCenters = 1;
			}
			
			// calculate total combinations
			totalCombinations *= amountOfFfmCenters;
		}
		
		// and return the amount
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, totalCombinations);
		return totalCombinations;			
	}
	
	/**
	 * Generates combination matrix from order items and the fulfillment centers
	 * @param orderItems list of order items
	 * @param numberOfTotalCombinations number of combinations
	 * @return combination matrix
	 */
	protected ArrayList<ArrayList<FulfillmentCenterInformation>> generateCombinationMatrix(ArrayList<OptimizationHelperBean> orderItems, Long numberOfTotalCombinations) {
		return generateCombinationMatrix(orderItems, numberOfTotalCombinations, null);
	}
	
	/**
	 * Generates combination matrix by order items, fulfillment centers and primary fulfillment center id
	 * @param orderItems list of order items
	 * @param numberOfTotalCombinations number of combinations
	 * @param primaryFulfillmentCenterId primary fulfillment center id if it is set
	 * @return combination matrix
	 */
	protected ArrayList<ArrayList<FulfillmentCenterInformation>> generateCombinationMatrix(ArrayList<OptimizationHelperBean> orderItems, Long numberOfTotalCombinations, Integer primaryFulfillmentCenterId) {
		final String METHOD_NAME = "generateCombinationMatrix()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { orderItems, numberOfTotalCombinations });
	
		// init the matrix
		ArrayList<ArrayList<FulfillmentCenterInformation>> combinationMatrix = new ArrayList();
		
		// init the repeation for ffm center 
		Long repeationForFulfillmentCenter = 1L;
		
		// loop through the order items
		for(int i = 0; i < orderItems.size(); i++) {
			// get the order item
			OptimizationHelperBean orderItem = orderItems.get(i);			
			
			// get all the capable fulfillment centers
			// copy list
			ArrayList<FulfillmentCenterInformation> ffmCenters = new ArrayList();			
			ffmCenters.addAll(orderItem.getFulfillmentCenters());

			// and check if the primary fulfillment center id was set
			if(primaryFulfillmentCenterId != null) {
				// loop through the ffm centers, and if it was found, init the list with ffm center entry
				for(FulfillmentCenterInformation ffmCenter : ffmCenters) {
					if(ffmCenter.getId().equals(primaryFulfillmentCenterId)) {
						ffmCenters.clear();
						ffmCenters.add(FulfillmentUtils.getFulfillmentCenter(primaryFulfillmentCenterId));
						break;
					}
				}
			}
			
			// add Y-axis entry
			combinationMatrix.add(i, generateCombinationMatrixEntry(ffmCenters, repeationForFulfillmentCenter, numberOfTotalCombinations)); 
			
			// and multiply the repeation for fulfillment center variable by amount of fulfillment center possibilities
			repeationForFulfillmentCenter *= ffmCenters.size();
		}
		
		// return the combination matrix
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		return combinationMatrix;
	}
	
	/**
	 * Gets all the combination entry objects from the matrix
	 * @param orderItems list of order items
	 * @param combinationMatrix
	 * @param totalCombinations
	 * @return
	 * @throws Exception
	 */
	protected ArrayList<OptimizationCombinationEntry> getCombinationEntries(ArrayList<OptimizationHelperBean> orderItems, ArrayList<ArrayList<FulfillmentCenterInformation>> combinationMatrix, Long totalCombinations) throws Exception {
		final String METHOD_NAME = "getCombinationEntries()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		ArrayList<OptimizationCombinationEntry> entries = new ArrayList();
		// init by impossible value
		Integer minimumAmountOfFulfillmentCenters = 10000;
		
		// loop through the combination entries
		for(int i = 0; i < totalCombinations; i++) {
			OptimizationCombinationEntry combination = new OptimizationCombinationEntry(); 
			
			// get the 'X-axis' info
			for(int j = 0; j < combinationMatrix.size(); j++) {
				// get the x-axis row
				ArrayList<FulfillmentCenterInformation> matrixEntry = combinationMatrix.get(j);
				// get the ffmcenter from y-axis
				FulfillmentCenterInformation ffmCenter = matrixEntry.get(i);
				// and then the order item from the list
				OptimizationHelperBean orderItem = orderItems.get(j);
				// and add the entry for combination
				combination.addEntry(ffmCenter.getId(), orderItem.getOrderItem());
			}
			
			// calculate total amount for fulfillment centers
			combination.calculateTotalAmounts();
			
			// if amount of combinations is lower than the saved minimum, save the info to the variable 
			if(minimumAmountOfFulfillmentCenters.compareTo(combination.getNumberOfDifferentFulfillmentCenters()) == 1) {
				minimumAmountOfFulfillmentCenters = combination.getNumberOfDifferentFulfillmentCenters();
			}
			
			// add combination entry to the list
			entries.add(combination);
		}

		try {
			int entrySum = entries.size();
			// filter entries by minimum amount of fulfillment centers
			ArrayList<OptimizationCombinationEntry> minimumFfmEntries = filterEntries(entries, minimumAmountOfFulfillmentCenters);
			int entryAmountAfterFiltering = minimumFfmEntries.size();
			
			if(entrySum != entryAmountAfterFiltering) {
				if(entryAmountAfterFiltering > 0) {
					entries = minimumFfmEntries;
				}
				
				ArrayList<OptimizationCombinationEntry> filteredEntries = filterEntriesByMaxPriority(entries);
				// and if the filtering was ok, replace the list
				if(filteredEntries != null && filteredEntries.size() > 0) {
					entries = filteredEntries;
				}
			}
		} catch(Exception e) {
			LOGGER.log(Level.SEVERE, "Unable to filter entries", e);
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, entries.size());
		return entries;
	}
	
	/**
	 * Checks if the fulfillment center is geolocation fulfillment center
	 * @param ffmCenter
	 * @return information about geolocation fulfillment center
	 */
	protected boolean isGeoLocationFulfillmentCenter(
			FulfillmentCenterInformation ffmCenter) {
		final String METHOD_NAME = "isGeoLocationFulfillmentCenter()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, ffmCenter);
		
		Boolean isGeoLocationFulfillmentCenter = this.geoLocationFfmCenter.getId().equals(ffmCenter.getId());
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, isGeoLocationFulfillmentCenter);
		return isGeoLocationFulfillmentCenter;
	}
	
	/**
	 * Filters fulfillment centers by overriding the list of fulfillment centers
	 * @param existingFfmCenters ffm centers to be filtered
	 * @param overrideFfmCenters ffm centers that will override the others
	 * @return filtered fulfillment centers
	 */
	protected ArrayList<FulfillmentCenterInformation> filterFulfillmentCenters(ArrayList<FulfillmentCenterInformation> existingFfmCenters, ArrayList<FulfillmentCenterInformation> overrideFfmCenters) {
		final String METHOD_NAME = "filterFulfillmentCenters()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { existingFfmCenters, overrideFfmCenters });
		
		// init fulfillment center list
		ArrayList<FulfillmentCenterInformation> filteredFfmCenters = new ArrayList();
		
		// loop through the override fulfillment centers
		for(FulfillmentCenterInformation ffmCenter : overrideFfmCenters) {
			// loop through the existing
			for(FulfillmentCenterInformation existingFfmCenter : existingFfmCenters) {
				// and if it was found, add the entry to the filtered list
				if(ffmCenter.getId().equals(existingFfmCenter.getId())) {
					filteredFfmCenters.add(ffmCenter);
				}
			}
		}
		
		// and if none of the override ffmcenters did not exist, add all the existing
		if(filteredFfmCenters.size() == 0) {
			filteredFfmCenters.addAll(existingFfmCenters);
		}
		
		// return the list
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		return filteredFfmCenters;
	}
	
	/**
	 * Generates combination matrix entry for y-axis
	 * @param ffmCenters list of fulfillment centers
	 * @param repeationForFulfillmentCenter how many times do we have to repeat the same fulfillment center
	 * @param numberOfTotalCombinations number of total combination, how long is the matrix?
	 * @return y-axis of the matrix
	 */
	protected ArrayList<FulfillmentCenterInformation> generateCombinationMatrixEntry(
			ArrayList<FulfillmentCenterInformation> ffmCenters,
			Long repeationForFulfillmentCenter, Long numberOfTotalCombinations) {
		final String METHOD_NAME = "generateCombinationMatrixEntry()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] {ffmCenters, repeationForFulfillmentCenter, numberOfTotalCombinations});
				
		// init combination matrix entry
		ArrayList<FulfillmentCenterInformation> combinationMatrixEntry = new ArrayList();
		
		// init fulfillment center index
		int ffmCenterIndex = 0;
		
		// loop through the total amount of combinations
		for(int i = 0; i < numberOfTotalCombinations; i++) {
			if(i > this.MAX_COMBINATION_LIMIT) {
				break;
			}
			combinationMatrixEntry.add(ffmCenters.get(ffmCenterIndex));
			
			// if we have to change the fulfillment center for matrix entry
			if((i != 0 && (i + 1) % repeationForFulfillmentCenter == 0) || repeationForFulfillmentCenter == 1) {
				++ffmCenterIndex;
			
				// oh noes, we are going out of bounds!
				if(ffmCenterIndex >= ffmCenters.size()) {
					ffmCenterIndex = 0;
				}
			}
		}
		
		// and return the y-axis
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		return combinationMatrixEntry;
	
	}
	
	/**
	 * Filters entries by minimum fulfillment center amount
	 * @param entries
	 * @param minimumAmountOfFulfillmentCenters
	 * @return
	 */
	protected ArrayList<OptimizationCombinationEntry> filterEntries(
			ArrayList<OptimizationCombinationEntry> entries,
			Integer minimumAmountOfFulfillmentCenters) {
		final String METHOD_NAME = "filterEntries()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] {minimumAmountOfFulfillmentCenters, entries.size() });
	
		// filtered entries list
		ArrayList<OptimizationCombinationEntry> filteredEntries = new ArrayList();
		
		// loop through the entry list and if the entry has the minimum amount of different fulfillment centers in the combination, that is ok
		for(OptimizationCombinationEntry entry : entries) {
			if(entry.getNumberOfDifferentFulfillmentCenters().compareTo(minimumAmountOfFulfillmentCenters) <= 0) {
				filteredEntries.add(entry);
			}
		}
		
		// return the filtered entries
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, filteredEntries.size());
		return filteredEntries;
	}

	
	/**
	 * Filter entries by max priority
	 * @param unFilteredEntries list of entries
	 * @return filteredEntries list of filtered entries
	 */
	protected ArrayList<OptimizationCombinationEntry> filterEntriesByMaxPriority(ArrayList<OptimizationCombinationEntry> unFilteredEntries) {
		final String METHOD_NAME = "filterEntriesByMaxPriority()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, unFilteredEntries);
		
		// fulfillment center ids
		Set<Integer> fulfillmentCenterIds = new HashSet();
		ArrayList<OptimizationCombinationEntry> filteredEntries = new ArrayList();
		
		// loop through unfiltered entries
		for(OptimizationCombinationEntry entry : unFilteredEntries) {
			// if fulfillment center ids exist
			if(fulfillmentCenterIds.size() == 0) {
				fulfillmentCenterIds.addAll(entry.getFulfillmentCenterIds());
			} else {
				// and loop through the all fulfillment centers
				for(Integer fulfillmentCenterId : entry.getFulfillmentCenterIds()) {
					if(!fulfillmentCenterIds.contains(fulfillmentCenterId)) {
						fulfillmentCenterIds.add(fulfillmentCenterId);
					}
				}
			}
		}
		
		// init list
		ArrayList<FulfillmentCenterInformation> ffmCenters = new ArrayList();
		
		// loop through fulfillment center ids
		for(Integer fulfillmentCenterId : fulfillmentCenterIds) {
			ffmCenters.add(FulfillmentUtils.getFulfillmentCenter(fulfillmentCenterId));
		}
		
		FulfillmentCenterInformation maxPriorityFfmCenter = ffmCenters.get(0);
		Boolean varying = false;
		
		for(FulfillmentCenterInformation ffmCenter : ffmCenters) {
			// if priority differs, set the information
			if(ffmCenter.getPriority().compareTo(maxPriorityFfmCenter.getPriority()) == 1) {
				maxPriorityFfmCenter = ffmCenter;
				varying = true;
			}
		}
		
		// if varying, filter the entries by ffm center id
		if(varying) {
			for(OptimizationCombinationEntry entry : unFilteredEntries) {
				for(Integer fulfillmentCenterId : entry.getFulfillmentCenterIds()) {
					if(maxPriorityFfmCenter.equals(fulfillmentCenterId)) {
						filteredEntries.add(entry);
						break;	
					}
				}
			}
		} else {
			filteredEntries.addAll(unFilteredEntries);
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		return filteredEntries;
	}
	
	/**
	 * Filters all the combination for order item entries
	 * @param orderItems list of orderitem helper bean
	 * @return list of combinations
	 * @throws Exception
	 */
	protected OptimizationCombinationEntry getMostOptimalCombination(ArrayList<OptimizationHelperBean> orderItems) throws Exception  {
		final String METHOD_NAME = "getMostOptimalCombination()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);		
		Long numberOfTotalCombinations = 1L;
		
		// calculate total combinations for orderItems
		for(OptimizationHelperBean orderItem : orderItems) {						
			numberOfTotalCombinations *= orderItem.getFulfillmentCenters().size();
		}
		
		// init combination matrix
		ArrayList<ArrayList<FulfillmentCenterInformation>> combinationMatrix = generateCombinationMatrix(orderItems, numberOfTotalCombinations);
		
		// and get the list of combination entry object from the matrix
		ArrayList<OptimizationCombinationEntry> entries = getCombinationEntries(orderItems, combinationMatrix, numberOfTotalCombinations);
		
		// sort the entries
		Collections.sort(entries, new OptimizationCombinationEntry.OptimizationCombinationComparator());
		
		// filter entries by max sum
		try {
			entries = filterEntriesByMaxSum(entries);
		} catch(Exception e) {
			LOGGER.log(Level.FINE, "Unable to filter entries by max sum", e);
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		return entries.get(0);
	}
	
	/**
	 * Filters entries by max sums
	 * @param entries list of all entries
	 * @return list of filtered entries
	 */
	protected ArrayList<OptimizationCombinationEntry> filterEntriesByMaxSum(ArrayList<OptimizationCombinationEntry> entries) {
		return filterEntriesByMaxSum(entries, 0);
	}
	
	
	/**
	 * Filters entries by max sum of current combination entry
	 * @param entries list of combination entry, must be sorted calling this
	 * @param index number of entry that we are going to handle
	 * @return list of filtered entries
	 */
	protected ArrayList<OptimizationCombinationEntry> filterEntriesByMaxSum(ArrayList<OptimizationCombinationEntry> entries, int index) {
		final String METHOD_NAME = "filterEntriesByMaxSum()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { entries.size(), index });
		
		// init filtered list
		ArrayList<OptimizationCombinationEntry> filteredEntries = new ArrayList();
		// init fulfillment center list
		ArrayList<FulfillmentCenterOptimizationBean> fulfillmentCenters = new ArrayList();
		
		// max sum entry
		OptimizationFulfillmentSumEntry maxSumEntry = entries.get(0).getSums().get(index);
		
		// loop through the existing entries
		for(OptimizationCombinationEntry entry : entries) {
			// get the sum entry that we are going to compare
			OptimizationFulfillmentSumEntry sumEntry = entry.getSums().get(index);
			
			// if max sum is equal to sum, let's add this
			if(maxSumEntry.getSum().compareTo(sumEntry.getSum()) == -1) {
				maxSumEntry = sumEntry;
			}
		}
		
		// loop through the entries again and resolve by the max sum
		for(OptimizationCombinationEntry entry : entries) {
			OptimizationFulfillmentSumEntry sumEntry = entry.getSums().get(index);
			
			if(sumEntry.getSum().equals(maxSumEntry.getSum())) {
				filteredEntries.add(entry);
			}
		}
		
		/*
		 * loop through the filtered list
		 * 
		 * check how many different fulfillment centers do we have here
		 */
		for(OptimizationCombinationEntry entry : filteredEntries) {
			OptimizationFulfillmentSumEntry sumEntry = entry.getSums().get(index);
			FulfillmentCenterInformation ffmCenter = sumEntry.getFulfillmentCenter();
			
			// hooray, it was not in the list 
			if(!fulfillmentCenters.contains(maxSumEntry.getFulfillmentCenter())) {
				FulfillmentCenterOptimizationBean helperBean = new FulfillmentCenterOptimizationBean(ffmCenter, 1L);
				
				if(isGeoLocationFulfillmentCenter(ffmCenter)) {
					helperBean.setGeoLocationFfmCenter(true);
				}
				// and add to the list
				fulfillmentCenters.add(helperBean);
			}
		}
		
		// if there are multiple entries
		if(fulfillmentCenters.size() > 1) {
			// sort the fulfillment centers
			Collections.sort(fulfillmentCenters, new FulfillmentCenterOptimizationBean.FulfillmentCenterOptimizationComparator());
			// get the most relevant
			FulfillmentCenterInformation ffmCenterToUse = fulfillmentCenters.get(0).getFfmCenter();
			
			// and then filter the entries by fulfillment center
			filteredEntries = filterEntriesByFfmCenter(filteredEntries, ffmCenterToUse, index);
		}
		
		
		// and if there are options available and we are not running out of bounds, let's do the filtering again 
		if(index + 1 < filteredEntries.get(0).getSums().size() && (filteredEntries.size() > 1)) {
			filteredEntries = filterEntriesByMaxSum(filteredEntries, ++index);
		} 
		
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, filteredEntries.size());
		return filteredEntries;
	}
	
	/**
	 * Filter entries by ffm center
	 * @param entries list of entries
	 * @param ffmCenter fulfillment center
	 * @param index the index of x-axis
	 * @return list of filtered entries
	 */
	protected ArrayList<OptimizationCombinationEntry> filterEntriesByFfmCenter(ArrayList<OptimizationCombinationEntry> entries, FulfillmentCenterInformation ffmCenter, int index) {
		final String METHOD_NAME = "filterEntriesByFfmCenter()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { entries.size(), ffmCenter, index });
		
		ArrayList<OptimizationCombinationEntry> filteredEntries = new ArrayList();
		
		for(OptimizationCombinationEntry entry : entries) {
			OptimizationFulfillmentSumEntry sumEntry = entry.getSums().get(index);
			
			if(sumEntry.getFulfillmentCenter().getId().equals(ffmCenter.getId())) {
				filteredEntries.add(entry);
			}
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, filteredEntries.size());
		return filteredEntries;
	}



	@Override
	public void setOrderItems(ArrayList<OptimizationHelperBean> orderItems) {
		this.orderItems = orderItems;
	}
	
	public Map<Integer, ArrayList<OrderItemAccessBean>> getMostOptimalCombination() {
		return mostOptimalCombinationMap;
	}
}
