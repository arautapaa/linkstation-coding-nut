

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.commerce.fulfillment.objects.FulfillmentCenterAccessBean;
import com.ibm.commerce.registry.RegistryManager;

public class FulfillmentCenterInformation {
	
	private Integer id;
	private Integer ownerFfmCenterId;
	private FulfillmentCenterInformation ownerFulfillmentCenter;
	
	private String identifier;
	private String externalStoreIdentifier;
	
	private Boolean defaultFfm = false;
	private RetailStoreDataBean retailStore;
	
	private Boolean scm;
	private String type;
	private Boolean forAllProducts = false;
	private Boolean active = false;
	
	private Set<String> types = new HashSet();
	
	private Integer priority;
	private Integer rows;
	
	private Integer storeId;
	
	private static final String CLASS_NAME = FulfillmentCenterInformation.class.getName();
	private static final Logger LOGGER = Logger.getLogger(CLASS_NAME);
	
	private static final RetailStoreRegistry retailStoreRegistry = (RetailStoreRegistry)RegistryManager.singleton().getRegistry(RetailStoreRegistry.REGISTRY_NAME);
	
	private static final String SQL_GET_EXTENDED_FFMCENTER_TYPES = "SQL_GET_EXTENDED_FFMCENTER_TYPES";
	
	public static class Builder {
		private FulfillmentCenterInformation ffmCenter;
		
				
		public Builder(Integer id) {
			ffmCenter = new FulfillmentCenterInformation();
			ffmCenter.setId(id);
		}
		
		public Builder ownerFfmCenterId(Integer ownerFfmCenterId) {
			if(ownerFfmCenterId != null && !ownerFfmCenterId.equals(0)) {
				ffmCenter.setOwnerFfmCenterId(ownerFfmCenterId);
			}
			return this;
		}
		
		public Builder defaultFfm(Boolean defaultFfm) {
			ffmCenter.setDefaultFfm(defaultFfm);
			return this;
		}
		
		public Builder storeId(Integer storeId) {
			ffmCenter.setStoreId(storeId);
			return this;
		}
		
		public FulfillmentCenterInformation build() {
			ffmCenter.initialize();
			return ffmCenter;
		}
	}
	
	public void initialize() {
		final String METHOD_NAME = "initialize()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME);
		
		try {
			// get the fulfillment center information
			FulfillmentCenterAccessBean ffmCenterAccessBean = new FulfillmentCenterAccessBean();
			ffmCenterAccessBean.setInitKey_fulfillmentCenterId(this.getId().toString());
			
			// get identifier from db
			String identifier = ffmCenterAccessBean.getName();
			
			// and set it to the object
			this.identifier = identifier;
			this.externalStoreIdentifier = ffmCenterAccessBean.getExternalFulfillmentStoreNumber();
			
			// normally the numeric value of identifier  means that it is retail store
			if(identifier.matches("\\d+")) {
				
				try {
					RetailStoreDataBean retailStore = retailStoreRegistry.getRetailStore(Integer.parseInt(identifier));
					// if it exists, it is retail store
					if(retailStore != null) {
						this.retailStore = retailStore;
					}
				} catch(Exception e) {
					LOGGER.log(Level.FINE, "Fulfillment center is not retail store.");
				}
			}
						
			initializeXffmCenterData(this.getId(), this.getStoreId());
		} catch(Exception e) {
			LOGGER.log(Level.WARNING, "Cannot resolve retail store information from database or registry", e);
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
	}
	
	protected void initializeXffmCenterData(Integer id, Integer storeId) {
		final String METHOD_NAME = "initializeXffmCenterData()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, id);
		
		try {
			XFfmcenterAccessBean xFfmCenterAB = new XFfmcenterAccessBean();
			xFfmCenterAB.setInitKey_ffmcenterId(id);
			xFfmCenterAB.setInitKey_storeId(storeId);
			scm = xFfmCenterAB.getScmFfmcenter();
			type = xFfmCenterAB.getFfmcenterType();
			types = getAllTypes(storeId, xFfmCenterAB.getFfmcenterType());
			forAllProducts = xFfmCenterAB.getDefaultFfmcenter();
			priority = xFfmCenterAB.getPriority();
			
			// check if ffm center is active
			Integer activeFlag = xFfmCenterAB.getActive();
			
			if(activeFlag != null && activeFlag.equals(1)) {
				active = true;
			}			
			
			LOGGER.log(Level.WARNING, "Adding fulfillment center " + getId() + ", " + getIdentifier() + " for " + getStoreId() + " with status " + (active ? "activated" : "deactivated"));
			
			rows = 0;
		} catch(Exception e) {
			
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME);
		
	}
	
	protected Set<String> getAllTypes(Integer storeId, String type) {
		final String METHOD_NAME = "getAllTypes()";
		LOGGER.entering(CLASS_NAME, METHOD_NAME, new Object[] { storeId, type });
		
		Set<String> types = new HashSet();
		
		types.add(type);
		
		try {
			
			Vector results = QueryHelper.executeParameterizedQuery(storeId.toString(), SQL_GET_EXTENDED_FFMCENTER_TYPES, new Object[] { type });
			
			Iterator<Vector> it = results.iterator();
			
			while(it.hasNext()) {
				Vector row = it.next();
				String parentType = (String)row.get(0);
				types.add(parentType);
			}
			
		} catch(Exception e) {
			
		}
		
		LOGGER.exiting(CLASS_NAME, METHOD_NAME, types);
		return types;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public Integer getOwnerFfmCenterId() {
		return ownerFfmCenterId;
	}

	public void setOwnerFfmCenterId(Integer ownerFfmCenterId) {
		this.ownerFfmCenterId = ownerFfmCenterId;
	}
	
	public Boolean isDefaultFfm() {
		return defaultFfm;
	}
	
	public void setDefaultFfm(Boolean defaultFfm) {
		this.defaultFfm = defaultFfm;
	}
	
	public FulfillmentCenterInformation getOwnerFulfillmentCenter() {
		return ownerFulfillmentCenter;
	}
	
	public void setOwnerFulfillmentCenter(FulfillmentCenterInformation ffmCenter) {
		this.ownerFulfillmentCenter = ffmCenter;
	}
	
	public RetailStoreDataBean getRetailStoreInformation() {
		return retailStore;
	}
	
	public Boolean isRetailStore() {
		return this.retailStore != null;
	}
	
	public String getExternalStoreIdentifier() {
		return externalStoreIdentifier;
	}

	public void setExternalStoreIdentifier(String externalStoreIdentifier) {
		this.externalStoreIdentifier = externalStoreIdentifier;
	}
	
	public Boolean getScm() {
		return scm;
	}

	public void setScm(Boolean scm) {
		this.scm = scm;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Integer getRows() {
		return rows;
	}
	
	public void addRows(Integer rows) {
		this.rows += rows;
	}

	public void setRows(Integer rows) {
		this.rows = rows;
	}

	public Boolean isForAllProducts() {
		return forAllProducts;
	}

	public void setForAllProducts(Boolean forAllProducts) {
		this.forAllProducts = forAllProducts;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Set<String> getTypes() {
		return types;
	}

	public void setTypes(Set<String> types) {
		this.types = types;
	}
	
	public static class FulfillmentCenterInformationComparator implements Comparator<FulfillmentCenterInformation> {

		@Override
		public int compare(FulfillmentCenterInformation o1,
				FulfillmentCenterInformation o2) {
			if(o2.isForAllProducts()) {
				return 1;
			} else if(o1.isForAllProducts()) {
				return -1;
			} else {
				return o2.getPriority().compareTo(o1.getPriority());
			}
		}
		
	}
}
