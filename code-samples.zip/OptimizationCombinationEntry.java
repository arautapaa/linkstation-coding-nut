import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.ibm.commerce.order.objects.OrderItemAccessBean;

/**
 * Helper class for Optimization comparison
 *
 */
public class OptimizationCombinationEntry {
	
	private Map<Integer, ArrayList<OrderItemAccessBean>> map = new HashMap();
	private Map<Integer, BigDecimal> totalSumsByFfmCenters = new HashMap();
	private BigDecimal maxSumFromFfmCenter = BigDecimal.ZERO;
	private Integer numberOfTotalFulfillmentCenters = 0;
	private ArrayList<OptimizationFulfillmentSumEntry> sums = new ArrayList();
	private FulfillmentCenterInformation maxSumFfmCenter = null;
	
	public Map<Integer, ArrayList<OrderItemAccessBean>> getResolvedCombinationMap() {
		return map;
	}
	
	public BigDecimal getMaxSum() {
		return maxSumFromFfmCenter;
	}
	
	public Set<Integer> getFulfillmentCenterIds() {
		return map.keySet();
	}
	
	public ArrayList<OptimizationFulfillmentSumEntry> getSums() {
		return sums;
	}
	
	/**
	 * Adds new order item for fulfillment center
	 * @param fulfillmentCenterId
	 * @param orderItem
	 */
	public void addEntry(Integer fulfillmentCenterId, OrderItemAccessBean orderItem) {
		
		// if map doesn't have the key, add it
		if(!map.containsKey(fulfillmentCenterId)) {
			numberOfTotalFulfillmentCenters++;
			map.put(fulfillmentCenterId, new ArrayList());
		}
		
		// add item to a list
		ArrayList<OrderItemAccessBean> orderItems = map.get(fulfillmentCenterId);
		orderItems.add(orderItem);
	}
	
	public Integer getNumberOfDifferentFulfillmentCenters() {
		return numberOfTotalFulfillmentCenters;
	}
	
	/**
	 * Calculates total amounts for fulfillment centers
	 * @throws Exception
	 */
	public void calculateTotalAmounts() throws Exception {
		
		// loop through the fulfillment centers
		for(Integer ffmCenterId : map.keySet()) {
			BigDecimal totalForFfmCenter = BigDecimal.ZERO;
			
			for(OrderItemAccessBean orderItem : map.get(ffmCenterId)) {
				totalForFfmCenter = totalForFfmCenter.add(orderItem.getTotalProductInEJBType());
			}
			
			// and add total sum
			totalSumsByFfmCenters.put(ffmCenterId, totalForFfmCenter);
		}
		
		// add sum entries
		ArrayList<OptimizationFulfillmentSumEntry> sumEntries = new ArrayList();
		
		// loop through the ffm centers
		for(Integer ffmCenterId : totalSumsByFfmCenters.keySet()) {
			FulfillmentCenterInformation ffmCenter = FulfillmentUtils.getFulfillmentCenter(ffmCenterId);			
			BigDecimal sum = totalSumsByFfmCenters.get(ffmCenterId);				
			sumEntries.add(new OptimizationFulfillmentSumEntry(ffmCenter, sum));
		}
		
		// and then sort by custom comparator
		Collections.sort(sumEntries, new OptimizationFulfillmentSumEntry.OptimizationFulfillmentSumEntryComparator());
		
		// and then add the max sum ffm center
		maxSumFfmCenter = sumEntries.get(0).getFulfillmentCenter();
		sums = sumEntries;
	}
	
	public FulfillmentCenterInformation getMaxSumFfmCenter() {
		return maxSumFfmCenter;
	}
	
	public String toString() {
		return String.format("Total price map: %s, max sum: %s", new Object[] { totalSumsByFfmCenters, maxSumFromFfmCenter });
	}
	
	public static class OptimizationCombinationComparator implements Comparator<OptimizationCombinationEntry> {
		@Override
		public int compare(OptimizationCombinationEntry o1,
				OptimizationCombinationEntry o2) {
			/*
			 * Rules are simple:
			 * Get max priority and then the max sum
			 */
			if(!o1.getMaxSumFfmCenter().getPriority().equals(o2.getMaxSumFfmCenter().getPriority())) {
				return o2.getMaxSumFfmCenter().getPriority().compareTo(o1.getMaxSumFfmCenter().getPriority());
			} else {
				return o2.getMaxSum().compareTo(o1.getMaxSum());
			}
		}		
	}
}

