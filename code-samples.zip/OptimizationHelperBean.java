import java.util.ArrayList;

import com.ibm.commerce.order.objects.OrderItemAccessBean;

public class OptimizationHelperBean {

	private ArrayList<FulfillmentCenterInformation> fulfillmentCenters = new ArrayList();
	private OrderItemAccessBean orderItem;
	private String fulfillmentCenterType;
	
	public OrderItemAccessBean getOrderItem() {
		return orderItem;
	}
	
	public void setOrderItem(OrderItemAccessBean orderItem) {
		this.orderItem = orderItem;
	}

	public ArrayList<FulfillmentCenterInformation> getFulfillmentCenters() {
		return fulfillmentCenters;
	}
	
	public void addFulfillmentCenter(FulfillmentCenterInformation ffmCenter) {
		fulfillmentCenters.add(ffmCenter);
	}
	
	public void setFulfillmentCenters(ArrayList<FulfillmentCenterInformation> fulfillmentCenters) {
		if(fulfillmentCenters != null) {
			this.fulfillmentCenters = fulfillmentCenters;
		}
	}
	
	public String getFulfillmentCenterType() {
		return fulfillmentCenterType;
	}
	
	public void setFulfillmentCenterType(String type) {
		this.fulfillmentCenterType = type;
	}

}
