import java.math.BigDecimal;
import java.util.Comparator;


public class OptimizationFulfillmentSumEntry {
	private BigDecimal sum;
	private FulfillmentCenterInformation fulfillmentCenter;
	
	public OptimizationFulfillmentSumEntry(FulfillmentCenterInformation fulfillmentCenter, BigDecimal sum) {
		this.fulfillmentCenter = fulfillmentCenter;
		this.sum = sum;
	}
	
	public BigDecimal getSum() {
		return sum;
	}
	
	public FulfillmentCenterInformation getFulfillmentCenter() {
		return fulfillmentCenter;
	}
	
	public static class OptimizationFulfillmentSumEntryComparator implements Comparator<OptimizationFulfillmentSumEntry>{

		@Override
		public int compare(OptimizationFulfillmentSumEntry o1,
				OptimizationFulfillmentSumEntry o2) {
			if(!o2.getFulfillmentCenter().getPriority().equals(o1.getFulfillmentCenter().getPriority())) {
				return o2.getFulfillmentCenter().getPriority().compareTo(o1.getFulfillmentCenter().getPriority());
			} else {
				return o2.getSum().compareTo(o1.getSum());
			}
		}
		
	}
}

